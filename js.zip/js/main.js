$(document).ready(function(){
	$('#nav').slicknav();
})